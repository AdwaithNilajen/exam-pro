from django.db import models

# Create your models here.
class studentreg(models.Model):
    name=models.CharField(max_length=50)
    registration_no=models.CharField(max_length=30)
    department=models.CharField(max_length=50)
    semester=models.IntegerField()
    image=models.ImageField(upload_to='upload/')
    