from django.shortcuts import render
from . models import studentreg

# Create your views here.
def index(request):
    return render(request,'index.html')

def studentregistration(request):
    if request.method=='POST':
        n = request.POST.get('name')
        r= request.POST.get('register')
        d= request.POST.get('department')
        s= request.POST.get('semester')
        i= request.POST.FILE('image')
        studentreg(name=n,registration_no=r,department=d,semester=s,image=i).save()
        return render(request,'index.html')
    else:    
        
        return render(request,'studentreg.html')