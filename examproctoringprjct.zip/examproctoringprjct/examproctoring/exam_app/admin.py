from django.contrib import admin
from . models import studentreg

# Register your models here.
admin.site.register(studentreg)